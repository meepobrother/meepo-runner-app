<?php
global $_W, $_GPC;
$data = array();
die(json_encode($data));
