<?php
global $_W, $_GPC;
$id = intval($_GPC['id']);
$return = array();
if (empty($id)) {
    $return['code'] = -1;
    $return['msg'] = '参数错误';
    die(json_encode($return));
}
$item = pdo_get('runner_open_tasks', array('id' => $id));
$item['subscribe_time'] = date('m-d H:i', $item['subscribe_time']);
$item['address'] = $item['from_address'] . $item['from_usernote'];
$item['subscribe_time_long'] = '约' . ($item['subscribe_time_long'] / 60) . '小时';

$return['code'] = 0;
$return['msg'] = '获取成功';
$return['data'] = $item;
die(json_encode($return));
