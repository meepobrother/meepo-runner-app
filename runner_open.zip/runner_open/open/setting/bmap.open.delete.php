<?php
$table = new BmapGeoTableModel();
$table->delete();