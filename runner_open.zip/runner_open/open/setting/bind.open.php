<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
cloudBind($input);
$return = array();
$return['msg'] = '保存成功';
die(json_encode($return));
