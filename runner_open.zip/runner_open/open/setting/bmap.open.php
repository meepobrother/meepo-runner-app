<?php
global $_W, $_GPC;
// ini_set('display_errors', true);
// error_reporting(E_ALL);

checkBmapTable();
$table = new BmapGeoTableModel();
$content = $table->list();
if ($content['status'] === 0) {
    $list = $content['geotables'];
}

$poi = new BmapPoiModel();
foreach ($list as $li) {
    if ($li['name'] === 'runner_open_tasks') {
        // createRunnerOpenTasksColumn($li['id']);
        // 同步数据
        $tasks = pdo_getall('runner_open_tasks', array());
        foreach ($tasks as $task) {
            $data = array();
            $data['title'] = $task['id'];
            $data['address'] = $task['from_address'];
            $data['tags'] = '任务';
            $data['latitude'] = $task['from_lat'];
            $data['longitude'] = $task['from_lng'];
            $data['coord_type'] = 3;
            $data['geotable_id'] = $li['id'];
            // column
            $data['task_status'] = $task['status'];
            $data['runner_money'] = $task['runner_money'];
            $data['task_desc'] = $task['note'];
            $data['from_avatar'] = $task['from_avatar'];
            $data['task_id'] = $task['id'];
            $data['origin_id'] = $task['origin_id'];
            $poi->create($data);
        }
    }
}

$setting = new SettingModel('bmap.geotables');
$setting->add($list);

// $column = new BmapColumnModel();
// $list = $poi->list(
//     array(
//         'geotable_id' => '1000003495',
//     )
// );

die(json_encode($list));

function checkBmapTable()
{
    $table = new BmapGeoTableModel();
    $content = $table->list();
    if ($content['status'] === 0) {
        $list = $content['geotables'];
    }
    // 检查是否完整
    // runner_open_tasks
    $data = array();
    $data['runner_open_tasks'] = false;
    $data['runner_open_runner'] = false;
    foreach ($list as $li) {
        if ($li['name'] === 'runner_open_tasks') {
            $data['runner_open_tasks'] = true;
        }
        if ($li['name'] === 'runner_open_runner') {
            $data['runner_open_runner'] = true;
        }
        $table->update(array(
            'id' => $li['id'],
            'is_published' => 1,
            'geotype'=>1
        ));
    }

    foreach ($data as $key => $has) {
        if (!$has) {
            $table->create(array(
                'name' => $key,
                'is_published' => 1,
                'geotype'=>1
            ));
        }
    }
}

function createRunnerOpenTasksColumn($id)
{
    // $c = array();
    // $c['geotable_id'] = $id;
    // $c['is_index_field'] = 0;
    // $c['type'] = '3';

    // // 设置表结构
    // $column = new BmapColumnModel();
    // $c['name'] = '任务名';
    // $c['key'] = 'task_title';
    // $c['is_search_field'] = 1;
    // $c['type'] = '3';
    // $column->create($c);

    // $c['name'] = '发单者头像';
    // $c['key'] = 'task_avatar';
    // $c['is_search_field'] = 0;
    // $c['type'] = '3';
    // $column->create($c);

    // $c['name'] = '跑腿佣金';
    // $c['key'] = 'task_price';
    // $c['is_search_field'] = 1;
    // $c['type'] = '2';
    // $column->create($c);

    // $c['name'] = '链接';
    // $c['key'] = 'task_url';
    // $c['is_search_field'] = 0;
    // $c['type'] = '3';
    // $column->create($c);
}
