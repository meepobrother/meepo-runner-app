<?php
global $_W, $_GPC;
// ini_set('display_errors', true);
// error_reporting(E_ALL);

checkBmapTable();
$table = new BmapGeoTableModel();
$content = $table->list();
if ($content['status'] === 0) {
    $list = $content['geotables'];
}

$poi = new BmapPoiModel();
foreach ($list as $li) {
    if ($li['name'] === 'runner_open_tasks') {
        // createRunnerOpenTasksColumn($li['id']);
        // 同步数据
        $tasks = pdo_getall('runner_open_tasks', array());
        foreach ($tasks as $task) {
            $data = array();
            $data['title'] = getTitle($task);
            $data['address'] = $task['from_address'] . $task['from_usernote'];
            $tags = getTaskTags($task);
            $data['tags'] = $tags;
            $data['latitude'] = $task['from_lat'];
            $data['longitude'] = $task['from_lng'];
            $data['coord_type'] = 3;
            $data['geotable_id'] = $li['id'];
            // column
            $data['status'] = $task['status'];
            $data['runner_money'] = $task['runner_money'];
            $data['addfee'] = $task['addfee'];
            $data['origin_id'] = $task['origin_id'];
            $data['to_address'] = $task['to_address'] . $task['to_usernote'];
            $data['subscribe_time'] = date('m-d H:i', $task['subscribe_time']);
            $data['special_type'] = $task['special_type'];
            $data['subscribe_type'] = $task['subscribe_type'];
            $data['send_type'] = $task['send_type'];
            $data['from_avatar'] = $task['from_avatar'];
            $data['siteroot'] = $_W['siteroot'];
            $data['task_id'] = $task['id'];
            $data['task_type'] = $task['task_type'];
            $data['note'] = $task['note'];
            $data['uniacid'] = $task['uniacid'] ? $task['uniacid'] : $_W['uniacid'];
            $poi->create($data);
        }
    }
}

$setting = new SettingModel('bmap.geotables');
$setting->add($list);

// $column = new BmapColumnModel();
// $list = $poi->list(
//     array(
//         'geotable_id' => '1000003495',
//     )
// );

die(json_encode($list));

function getTitle($task)
{
    $tag = '';
    if ($task['subscribe_type'] == '0') {
        $tag .= "立即-";
    }
    if ($task['subscribe_type'] == '1') {
        $tag .= "预约-";
    }
    if ($task['send_type'] == '1') {
        $tag .= "帮买";
    } else if ($task['send_type'] == '2') {
        $tag .= "帮送";
    } else if ($task['send_type'] == '3') {
        $tag .= "帮取";
    } else if ($task['send_type'] == '4') {
        $tag .= "排队";
    }
    return $tag;
}

function getTaskTags($task)
{
    $tag = '任务';
    if ($task['send_type'] == '1') {
        $tag .= "|帮买";
    }
    if ($task['send_type'] == '2') {
        $tag .= "|帮送";
    }
    if ($task['send_type'] == '3') {
        $tag .= "|帮取";
    }
    if ($task['send_type'] == '4') {
        $tag .= "|排队";
    }
    if ($task['subscribe_type'] == '0') {
        $tag .= "|立即";
    }
    if ($task['subscribe_type'] == '1') {
        $tag .= "|预约";
    }
    return $tag;
}

function checkBmapTable()
{
    $table = new BmapGeoTableModel();
    $content = $table->list();
    if ($content['status'] === 0) {
        $list = $content['geotables'];
    }
    // 检查是否完整
    // runner_open_tasks
    $data = array();
    $data['runner_open_tasks'] = false;
    $data['runner_open_runner'] = false;
    foreach ($list as $li) {
        if ($li['name'] === 'runner_open_tasks') {
            $data['runner_open_tasks'] = true;
        }
        if ($li['name'] === 'runner_open_runner') {
            $data['runner_open_runner'] = true;
        }
        $table->update(array(
            'id' => $li['id'],
            'is_published' => 1,
            'geotype' => 1,
        ));
    }

    foreach ($data as $key => $has) {
        if (!$has) {
            $table->create(array(
                'name' => $key,
                'is_published' => 1,
                'geotype' => 1,
            ));
        }
    }
}

function createRunnerOpenTasksColumn($id)
{
    // $c = array();
    // $c['geotable_id'] = $id;
    // $c['is_index_field'] = 0;
    // $c['type'] = '3';

    // // 设置表结构
    // $column = new BmapColumnModel();
    // $c['name'] = '任务名';
    // $c['key'] = 'task_title';
    // $c['is_search_field'] = 1;
    // $c['type'] = '3';
    // $column->create($c);

    // $c['name'] = '发单者头像';
    // $c['key'] = 'task_avatar';
    // $c['is_search_field'] = 0;
    // $c['type'] = '3';
    // $column->create($c);

    // $c['name'] = '跑腿佣金';
    // $c['key'] = 'task_price';
    // $c['is_search_field'] = 1;
    // $c['type'] = '2';
    // $column->create($c);

    // $c['name'] = '链接';
    // $c['key'] = 'task_url';
    // $c['is_search_field'] = 0;
    // $c['type'] = '3';
    // $column->create($c);
}
