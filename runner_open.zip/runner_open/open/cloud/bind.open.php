<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$params = array();
$params['uniacid'] = $input['uniacid'];
$params['siteroot'] = $input['siteroot'];

$item = pdo_get('runner_open_cloud_bind', $params);
if (empty($item)) {
    pdo_insert('runner_open_cloud_bind', $input);
} else {
    pdo_update('runner_open_cloud_bind', $input, $params);
}

die(json_encode($input));
