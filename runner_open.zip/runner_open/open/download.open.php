<?php
global $_W, $_GPC;
$url = $_W['siteroot'].'/addons/runner_open/tpl/runner_open_demo.zip';
header("Location:".$url);
exit();
