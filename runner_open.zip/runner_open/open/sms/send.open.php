<?php
global $_W, $_GPC;

$input = $_GPC['__input'];
$mobile = $input['mobile'];
$full = $input['pre'] . $input['mobile'];

// max time
$maxTime = 60;
$maxCount = 5;

$re = array();
$re['code'] = 0;
$re['msg'] = '发送成功';
$re['data'] = array();

$data = array();
$data['code'] = random(4, true);
$data['mobile'] = $input['mobile'];
$data['pre'] = $input['pre'];
$data['full'] = $input['pre'] . $input['mobile'];

$data['uniacid'] = $_W['uniacid'];
$data['create_time'] = time();

// 查找重复
$sql = "SELECT * FROM " . tablename('runner_open_sms') . " WHERE full=:full AND uniacid=:uniacid AND create_time >:create_time";
$params = array(
    ':full' => $full,
    ':uniacid' => $_W['uniacid'],
    ':create_time' => time() - $maxTime, // 60秒
);
$list = pdo_fetchall($sql, $params);

$params[':create_time'] = strtotime(date('Y-m-d'));
$todayList = pdo_fetchall($sql, $params);

$count = count($list);
if ($count > 0) {
    $re['code'] = -1;
    $re['msg'] = '发送太频繁了，请稍后再试！';
    $re['data'] = $list;
    die(json_encode($re));
}

$todayCount = count($todayList);
if ($todayCount > $maxCount) {
    $re['code'] = -1;
    $re['msg'] = '已超过今日次数，请择日再试！';
    die(json_encode($re));
}
pdo_insert('runner_open_sms', $data);
$id = pdo_insertid();
$re['data'] = $id;
die(json_encode($re));
