<?php
global $_W, $_GPC;

$input = $_GPC['__input'];
$mobile = $input['mobile'];
$full = $mobile['pre'] . $mobile['mobile'];

$code_id = intval($input['code_id']);
$code = trim($input['code']);
if (empty($code) || empty($code_id) || empty($full)) {
    $re['code'] = -1;
    $re['msg'] = '参数错误';
    die(json_encode($re));
}
$re = array();
$re['code'] = 0;
$re['msg'] = '发送成功';
$re['data'] = array();
$params = array('id' => $code_id);
$item = pdo_get('runner_open_sms', $params);

if (empty($item)) {
    $re['code'] = -1;
    $re['msg'] = '验证码错误';
    die(json_encode($re));
} else {
    if ($item['full'] != $full) {
        $re['code'] = -1;
        $re['msg'] = '手机号与验证码不匹配';
        $re['data'] = $full;
        die(json_encode($re));
    }
    if ($item['code'] != $code) {
        $re['code'] = -1;
        $re['msg'] = '验证码错误';
        die(json_encode($re));
    }
}

$re['msg'] = '验证通过';
$re['data'] = $input;
// 自动登录
$member = pdo_get('mc_members', array('mobile' => $mobile));
if (empty($member)) {
    $default_groupid = pdo_fetchcolumn('SELECT groupid FROM ' . tablename('mc_groups') . ' WHERE uniacid = :uniacid AND isdefault = 1', array(':uniacid' => $_W['uniacid']));
    $data = array();
    $data['uniacid'] = $_W['uniacid'];
    $data['mobile'] = $mobile['mobile'];
    $data['salt'] = random(8);
    $password = random(6);
    $data['password'] = md5($password . $data['salt'] . $_W['config']['setting']['authkey']);
    $data['groupid'] = $default_groupid;
    $data['residecity'] = $input['city'];
    pdo_insert('mc_members', $data);
    $uid = pdo_insertid();
} else {
    $uid = $member['uid'];
}

$re['uid'] = $uid;

// 删除之前的sign
pdo_delete('runner_open_login', array('uid' => $uid));
// 生成sign
$data = array();
$data['uid'] = $uid;
$data['notice_str'] = random(16, false);
$data['exporess_in'] = time() + 60 * 60 * 30;
$data['sign'] = bulidSign($data);
pdo_insert('runner_open_login', $data);

$re['sign'] = $data['sign'];

$member = pdo_get('mc_members', array('uid' => $uid, 'uniacid' => $_W['uniacid']));
$user = array();
$user['sign'] = $member['bio'];
$user['realname'] = $member['realname'];
$user['nickname'] = $member['nickname'];
$user['avatar'] = $member['avatar'];
$user['cardnum'] = $member['idcard'];
$user['sex'] = $member['gender'];

$re['user'] = $user;
die(json_encode($re));
