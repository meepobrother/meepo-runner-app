<?php
global $_W, $_GPC;
$data = registerRunner();
die(json_encode($data));
