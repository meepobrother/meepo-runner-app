<?php
global $_W, $_GPC;
// 下班
