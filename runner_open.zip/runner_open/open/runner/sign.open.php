<?php
global $_W, $_GPC;
// 上班
