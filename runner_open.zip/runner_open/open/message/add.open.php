<?php
global $_W, $_GPC;
$input = $_GPC['__input'];

$data = array();
$data['title'] = $input['title'];
$data['content'] = $input['content'];
$data['link'] = $input['link'];
$data['create_time'] = time();
$data['status'] = 0;
$data['type'] = $input['type'];
$data['icon'] = $input['icon'];
$data['uid'] = $input['uid'];
$data['fuid'] = $input['fuid'];

pdo_insert('runner_open_message', $data);
$data['id'] = pdo_insertid();
die(json_encode($data));

