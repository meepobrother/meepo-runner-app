<?php
global $_W, $_GPC;
$input = $_GPC['__input'];

$uid = $_W['member']['uid'];

$list = pdo_getall('runner_open_message', array('uid' => $uid, 'status' => 0));

die(json_encode($list));
