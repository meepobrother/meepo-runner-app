<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$id = $input['id'];
pdo_update('runner_open_message', array('status' => 1), array('id' => $id));
die(json_encode($input));
