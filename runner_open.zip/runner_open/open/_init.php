<?php
// 引入mod
include IA_ROOT . "/addons/runner_open/model/setting.mod.php";
include IA_ROOT . "/addons/runner_open/model/bmap.base.mod.php";
include IA_ROOT . "/addons/runner_open/model/bmap.v3.geotable.mod.php";
include IA_ROOT . "/addons/runner_open/model/bmap.v3.column.mod.php";
include IA_ROOT . "/addons/runner_open/model/bmap.v3.poi.mod.php";
include IA_ROOT . "/addons/runner_open/model/bmap.v3.geosearch.mod.php";

// 引入function
include IA_ROOT . "/addons/runner_open/open/_function.php";
