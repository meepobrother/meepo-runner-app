<?php
global $_W, $_GPC;
// 自定义业务地点的位置描述
// 普通逆地理编码服务中，解析坐标所在行政区划，同时召回周边权重较高的POI数据用于位置描述。
// 云逆地理编码服务中，用户可使用在云存储中管理的自定义地点数据，对坐标进行个性化的位置描述。
$input = $_GPC['__input'];
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
$params = array();
$params['location'] = $input['lat'] . ',' . $input['lng'];
$params['geotable_id'] = $input['geotable_id'];
$params['coord_type'] = $input['coord_type'];
$params['ak'] = $ak;
$url = 'http://api.map.baidu.com/cloudrgc/v1?' . http_build_query($params);
load()->func('communication');
$re = ihttp_get($url);
$content = json_decode($re['content'], true);
die(json_encode($content));