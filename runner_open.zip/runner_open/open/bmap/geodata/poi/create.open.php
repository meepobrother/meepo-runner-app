<?php
global $_W, $_GPC;
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
$input = $_GPC['__input'];
$data = array();
$data['title'] = $input['title'];
$data['address'] = $input['address'];
$data['tags'] = $input['tags'];
$data['latitude'] = $input['latitude'];
$data['longitude'] = $input['longitude'];
$data['polygons'] = $input['polygons'];
$data['coord_type'] = $input['coord_type'];
$data['geotable_id'] = !empty($input['geotable_id']) ? $input['geotable_id'] : '186480';
$data['ak'] = $ak;
$data['icon_style_id'] = $input['icon_style_id'];
$data['subscribe_time'] = $input['subscribe_time'];
$data['subscribe_type'] = $input['subscribe_type'];
$data['special_type'] = $input['special_type'];
$data['send_type'] = $input['send_type'];
$data['origin_id'] = $input['origin_id'];

$url = 'http://api.map.baidu.com/geodata/v4/poi/create';

load()->func('communication');
$re = ihttp_post($url, $data);
$content = json_decode($re['content'], true);

var_dump($data);
die(json_encode($content));
