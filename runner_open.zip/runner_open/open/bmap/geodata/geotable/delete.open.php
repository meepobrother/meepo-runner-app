<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$url = 'http://api.map.baidu.com/geodata/v4/geotable/delete';
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';

$params = array();
$params['id'] = $input['id'];
$params['ak'] = $ak;
load()->func('communication');
$re = ihttp_post($url, $params);
$content = json_decode($re['content'], true);
die(json_encode($content));
