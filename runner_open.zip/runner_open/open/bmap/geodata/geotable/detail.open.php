<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';

$params = array();
$params['id'] = $input['id'];
$params['ak'] = $ak;

$url = 'http://api.map.baidu.com/geodata/v3/geotable/detail?' . http_build_query($params);

load()->func('communication');
$re = ihttp_get($url);
$content = json_decode($re['content'], true);
die(json_encode($content));
