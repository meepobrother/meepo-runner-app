<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$url = 'http://api.map.baidu.com/geodata/v4/geotable/update';
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
$input['ak'] = $ak;

load()->func('communication');
$re = ihttp_post($url, $input);
$content = json_decode($re['content'], true);
die(json_encode($content));
