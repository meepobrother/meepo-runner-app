<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$name = $_GPC['name'];
$table = new BmapGeoTableModel();
$content = $table->create($name);
die(json_encode($content));
