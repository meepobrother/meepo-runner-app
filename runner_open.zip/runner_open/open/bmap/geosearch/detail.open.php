<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$uid = $input['uid'];
$url = 'http://api.map.baidu.com/geosearch/v3/detail/' . $uid;
load()->func('communication');
$re = ihttp_get($url);
$content = json_decode($re['content'], true);
die(json_encode($content));
