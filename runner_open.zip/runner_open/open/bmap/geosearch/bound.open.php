<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
$params = array();
$params['geotable_id'] = $input['geotable_id'];
$params['bounds'] = $input['bounds'];
$params['tags'] = $input['tags'];
$params['sortby'] = $input['sortby'];
$params['filter'] = $input['filter'];
$params['ak'] = $ak;
$url = 'http://api.map.baidu.com/geosearch/v3/bound?' . http_build_query($params);
load()->func('communication');
$re = ihttp_get($url);
$content = json_decode($re['content'], true);
die(json_encode($content));
