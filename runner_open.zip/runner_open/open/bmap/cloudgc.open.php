<?php
global $_W, $_GPC;
/**
 * 训练更准确的位置坐标
 * 输入结构化地址：「北京市海淀区科技园1号楼二单元」
 * 通过百度自有地址数据解析结果为：“lat:41.055743,lng:116.308243”
 * 用户根据真实场景，在云端将坐标训练为：“lat:41.056743,lng:116.308243”
 */
$input = $_GPC['__input'];
$ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
$params = array();
$params['geotable_id'] = $input['geotable_id'];
$params['address'] = $input['address'];
$params['city'] = $input['city'];
$params['ak'] = $ak;
$url = 'http://api.map.baidu.com/cloudgc/v1?' . http_build_query($params);
load()->func('communication');
$re = ihttp_get($url);
$content = json_decode($re['content'], true);
die(json_encode($content));