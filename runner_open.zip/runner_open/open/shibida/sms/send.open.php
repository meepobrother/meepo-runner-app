<?php
global $_W,$_GPC;
$data = array(
    'status'=>0
);
$json = json_encode($data);
die(json_encode($data));
