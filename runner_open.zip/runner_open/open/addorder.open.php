<?php
global $_W, $_GPC;
$input = $_GPC['__input'];
$price_token = $input['price_token'];
load()->func('cache');
$return = array();

$item = cache_load($price_token);
if (empty($item)) {
    $return['return_msg'] = '项目不存在或已过期';
    $return['return_code'] = 'fail';
    die(json_encode($return));
}
$item = json_decode($item, true);

// 对照金额
if ($item['need_paymoney'] != $input['need_paymoney']) {
    $return['return_msg'] = '支付金额有误';
    $return['return_code'] = 'fail';
    die(json_encode($return));
}

$data = array();
$data['origin_id'] = $input['origin_id'];
$data['from_address'] = $input['from_address'];

$data['from_usernote'] = $input['from_usernote'];
$data['to_address'] = $input['to_address'];

$data['to_usernote'] = $input['to_usernote'];
$data['city_name'] = $input['city_name'];

$data['county_name'] = $input['county_name'];
$data['push_type'] = $input['push_type'];

$data['subscribe_type'] = $input['subscribe_type'];
$data['callme_withtake'] = $input['callme_withtake'];

$data['status'] = $input['status'];
$data['goods_needpay'] = $input['goods_needpay'];

$data['push_str'] = $input['push_str'];
$data['special_type'] = $input['special_type'];
$data['subscribe_time'] = $input['subscribe_time'];
$data['subscribe_time_long'] = $input['subscribe_time_long'];
$data['coupon_id'] = $input['coupon_id'];
$data['send_type'] = $input['send_type'];
$data['timestamp'] = $input['timestamp'];

$data['uniacid'] = $input['uniacid'];
$data['openid'] = $input['openid'];
$data['appid'] = $input['appid'];
$data['to_lat'] = $input['to_lat'];
$data['to_lng'] = $input['to_lng'];
$data['from_lat'] = $input['from_lat'];

$data['from_lng'] = $input['from_lng'];
$data['nonce_str'] = $input['nonce_str'];
$data['sign'] = $input['sign'];
$data['distance'] = $input['distance'];
$data['freight_money'] = $input['freight_money'];
$data['need_paymoney'] = $input['need_paymoney'];

$data['total_priceoff'] = $input['total_priceoff'];
$data['goods_price'] = $input['goods_price'];
$data['goods_weight'] = $input['goods_weight'];
$data['goods_insurance_money'] = $input['goods_insurance_money'];
$data['other_fee'] = $input['other_fee'];

$data['addfee'] = $input['addfee'];
$data['coupon_amount'] = $input['coupon_amount'];
$data['runner_money'] = $input['runner_money'];
$data['countpay'] = $input['countpay'];
$data['goods_tool'] = $input['goods_tool'];
$data['note'] = $input['note'];

$data['receiver'] = $input['receiver'];
$data['receiver_phone'] = $input['receiver_phone'];
$data['pubusermobile'] = $input['pubusermobile'];
$data['callback_url'] = $input['callback_url'];
$data['countpay'] = $input['countpay'];
$data['goods_type'] = $input['goods_type'];
$data['goods_name'] = $input['goods_name'];

$data['add_time'] = $input['add_time'];
$data['finish_time'] = $input['finish_time'];
$data['start_level'] = $input['start_level'];
$data['expires_in'] = $input['expires_in'];
$data['comment_note'] = $input['comment_note'];

$data['driver_name'] = $input['driver_name'];
$data['driver_jobnum'] = $input['driver_jobnum'];
$data['driver_mobile'] = $input['driver_mobile'];
$data['driver_lastloc'] = $input['driver_lastloc'];

if (pdo_insert('runner_open_tasks', $data)) {
    $return['error_code'] = 'ok';
    $return['error_msg'] = '创建订单成功';
    $return['id'] = pdo_insertid();
    die(json_encode($return));
} else {
    $item = pdo_get('runner_open_tasks', array('origin_id' => $data['origin_id'], 'status' => 0));
    if (empty($item)) {
        $return['error_code'] = 'fail';
        $return['error_msg'] = '重复订单';
        $return['id'] = $item['id'];
        die(json_encode($return));
    }
    if (!empty($item)) {
        pdo_update('runner_open_tasks', $data, array('origin_id' => $data['origin_id'], 'status' => 0));
    }
    $return['error_code'] = 'ok';
    $return['error_msg'] = '创建订单成功';
    $return['id'] = $item['id'];
    die(json_encode($return));
}

die(json_encode($return));
