<?php
global $_W,$_GPC;

$input = $_GPC['__input'];
