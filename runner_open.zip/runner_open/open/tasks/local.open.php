<?php
global $_W, $_GPC;
$search = new BmapGeosearchModel();
$list = $search->local(array(
    'q' => '',
    'geotable_id' => '186498',
    'sortby' => 'distance:1|runner_money:1|addtime:1',
));
die(json_encode($list));
