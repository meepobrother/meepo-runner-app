<?php
if (pdo_tableexists('runner_open_token')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_token'));
}
if (pdo_tableexists('runner_open_tasks')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_tasks'));
}
if (pdo_tableexists('runner_open_setting')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_setting'));
}
if (pdo_tableexists('runner_open_runner')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_runner'));
}
if (pdo_tableexists('runner_open_login')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_login'));
}
if (pdo_tableexists('runner_open_sms')) {
    pdo_query("DROP TABLE IF EXISTS " . tablename('runner_open_sms'));
}
