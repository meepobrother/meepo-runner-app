<?php
class GeoData
{
    public static $ak = 'RG62whHySODgV1Mq1jHhDFBkBLyjglQu';
}
