<?php

class BmapJobModel extends BmapBaseModel
{
    public function list() {}
}
