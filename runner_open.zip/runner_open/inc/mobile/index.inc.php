<?php
global $_W, $_GPC;
$this->checkMobileDo('index');
include $this->template('index');
